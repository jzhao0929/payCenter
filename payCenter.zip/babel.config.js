/**
 * made by jzhao.
 **/

module.exports = {
  presets: [
    '@vue/app'
  ]
}
