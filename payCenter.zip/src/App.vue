<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
/**
 * made by jzhao.
 **/
export default {
  name: 'App'
}
</script>
