<template>
  <div>今日数据</div>
</template>

<script>
export default {

}
</script>

<style>

</style>