<template>
  <div>历史数据</div>
</template>

<script>
export default {

}
</script>

<style>

</style>